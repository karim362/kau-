// هذا الملف خاص بمفاتيح الربط مع المواقع الخارجية (APIs)

// مفتاح OpenCageData لجلب احداثيات المدن
const OPENCAGE_API_KEY = "2bae061bcafa45b2a7cfbeb395c52975";

// بيانات AstronomyAPI لمواقع الكواكب
const ASTRONOMY_API_ID = "0674d1a2-abd2-488c-a4f2-fe21743f8a98";
const ASTRONOMY_API_SECRET = "e2d12072585f550def86af89ec5fcfd2a36d88faf72280c68753018f8b2e053062015da957df3c2db9d90d6fa00fd49ba8dcbe58ac574de84bdb96141dbf9c05925f8b93159822e5d446147a30288d90e1f8384b3212259e7fad80b63be8e638932a0a19c487b6e9e13ec91e2ed39304";

// عنوان قاعدة Astronomy API
const SERVER_API_BASE = "https://g-j5vhifme3-karims-projects-9848714c.vercel.app";