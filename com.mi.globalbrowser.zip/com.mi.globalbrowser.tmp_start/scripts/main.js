document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('birth-form');
    const chartSection = document.getElementById('chart-section');
    const userNameEl = document.getElementById('user-name');
    const chartCanvas = document.getElementById('zodiac-chart');
    const downloadBtn = document.getElementById('download-chart');
    let zodiacChartInstance = null;

    // عند إرسال النموذج
    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        const name = document.getElementById('name').value.trim();
        const birthdate = document.getElementById('birthdate').value;
        const birthtime = document.getElementById('birthtime').value || "12:00";
        const city = document.getElementById('city').value.trim();

        if (!name || !birthdate || !city) {
            alert("الرجاء ملء جميع الحقول المطلوبة.");
            return;
        }

        try {
            userNameEl.textContent = `الخريطة الفلكية الخاصة بـ ${name}`;

            // الحصول على إحداثيات المدينة
            const coords = await getCityCoordinates(city);
            if (!coords) {
                alert("لم يتم العثور على إحداثيات المدينة.");
                return;
            }

            // جلب بيانات الكواكب
            const planets = await getPlanetsPositions(coords.lat, coords.lng, birthdate, birthtime);

            // رسم الخريطة
            drawZodiacChart(planets);

            // عرض القسم
            chartSection.style.display = 'block';

        } catch (error) {
            console.error(error);
            alert("حدث خطأ أثناء إنشاء الخريطة.");
        }
    });

    // زر تحميل الخريطة
    downloadBtn.addEventListener('click', function () {
        if (!zodiacChartInstance) return;
        const link = document.createElement('a');
        link.download = 'zodiac_chart.png';
        link.href = chartCanvas.toDataURL('image/png');
        link.click();
    });

    // دوال المساعدة

    async function getCityCoordinates(city) {
        try {
            const response = await axios.post(`${SERVER_API_BASE}/get-coordinates`, { city });
            return response.data;
        } catch (error) {
            console.error('خطأ أثناء جلب الإحداثيات:', error);
            throw error;
        }
    }

    async function getPlanetsPositions(lat, lng, date, time) {
        try {
            const response = await axios.post(`${SERVER_API_BASE}/get-planets`, {
                lat,
                lng,
                date,
                time
            });
            return response.data;
        } catch (error) {
            console.error('خطأ أثناء جلب مواقع الكواكب:', error);
            throw error;
        }
    }

    function drawZodiacChart(planets) {
        if (zodiacChartInstance) {
            zodiacChartInstance.destroy();
        }

        const ctx = chartCanvas.getContext('2d');
        const labels = planets.map(p => p.name);
        const data = planets.map(p => p.position);

        zodiacChartInstance = new Chart(ctx, {
            type: 'polarArea',
            data: {
                labels: labels,
                datasets: [{
                    label: 'مواقع الكواكب',
                    data: data,
                    backgroundColor: generateColors(data.length),
                }]
            },
            options: {
                scales: {
                    r: {
                        ticks: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    function generateColors(count) {
        const colors = [
            '#6a3093', '#a044ff', '#9d50bb', '#8e2de2', '#c471ed',
            '#f64f59', '#ff6a00', '#ff9966', '#7f00ff', '#e100ff',
            '#4facfe', '#43e97b'
        ];
        const generated = [];
        for (let i = 0; i < count; i++) {
            generated.push(colors[i % colors.length]);
        }
        return generated;
    }
});